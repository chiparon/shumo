"""Plot archived nominal samples only; never invoke or alter a solver."""
from pathlib import Path
import hashlib
import json

import numpy as np

BASE = Path(__file__).resolve().parent
RUNS = {"q1": "q1_n3200", "q23": "q23_n12800", "q4": "q4_n12800"}


def main():
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    output = BASE / "figures"
    output.mkdir(exist_ok=True)
    plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 9,
                         "axes.spines.top": False, "axes.spines.right": False,
                         "savefig.dpi": 200})
    fields, evidence = {}, {"scope": "Nominal archived 21 fixed-radius samples plus recorded moving surface; no full interior trajectory reconstructed", "runs": {}}
    for q, run in RUNS.items():
        path = BASE / "runs" / run / "fields.npz"
        with np.load(path, allow_pickle=False) as archive:
            data = {key: archive[key] for key in archive.files}
        data["radii_m"] = data["radius_m"] if q == "q1" else data["radii_m"]
        if q == "q1":
            data["surface_temperature_C"] = data["temperature_C"][:, -1]
            data["surface_moisture_dry_kgkg"] = data["moisture_dry_kgkg"][:, -1]
        data["sample_max_C"] = np.maximum(np.nanmax(data["moisture_dry_kgkg"], axis=1), data["surface_moisture_dry_kgkg"])
        fields[q] = data
        moments = [100, 600, 1800] if q == "q1" else [1800, 14400, 86400, 172800]
        indices = sorted(set([int(np.argmin(abs(data["time_s"] - t))) for t in moments] + [len(data["time_s"]) - 1]))
        samples = [{"time_s": float(data["time_s"][i]), "center_temperature_C": float(data["temperature_C"][i, 0]),
                    "surface_temperature_C": float(data["surface_temperature_C"][i]),
                    "center_moisture": float(data["moisture_dry_kgkg"][i, 0]),
                    "surface_moisture": float(data["surface_moisture_dry_kgkg"][i]),
                    "sample_max_moisture": float(data["sample_max_C"][i]),
                    "radius_cm": 2.0 if q == "q1" else float(data["radius_m"][i] * 100)} for i in indices]
        crossings = {}
        for threshold in [1.0, 0.5, 0.3, 0.2, 0.15]:
            found = np.flatnonzero(data["sample_max_C"] < threshold)
            crossings[str(threshold)] = float(data["time_s"][found[0]]) if found.size else None
        gradient = data["surface_temperature_C"] - data["temperature_C"][:, 0]
        peak = int(np.argmax(abs(gradient)))
        evidence["runs"][q] = {"source": path.relative_to(BASE).as_posix(), "sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
            "radial_sample_count": int(data["temperature_C"].shape[1]), "samples": samples,
            "first_saved_sample_below_s": crossings, "largest_saved_surface_minus_center_temperature_C": float(gradient[peak]),
            "largest_gradient_sample_time_s": float(data["time_s"][peak]),
            "endpoint_full_grid_max_moisture": None if q == "q1" else float(np.max(data["final_moisture_dry_kgkg"]))}

    colors = {"q1": "#667085", "q23": "#156b92", "q4": "#aa4c24"}
    labels = {"q1": "Q1", "q23": "Q2/Q3", "q4": "Q4"}
    fig, axes = plt.subplots(1, 2, figsize=(7.0, 2.9), constrained_layout=True)
    for q, data in fields.items():
        for ax in axes:
            if ax is axes[1] and q == "q1":
                continue
            mask = data["time_s"] <= 14400 if ax is axes[0] else np.ones(len(data["time_s"]), dtype=bool)
            for values, style, loc in [(data["temperature_C"][:, 0], "-", "center"), (data["surface_temperature_C"], "--", "surface")]:
                ax.plot(data["time_s"][mask] / 3600, values[mask], style, color=colors[q], lw=1.2, label=f"{labels[q]} {loc}")
        axes[0].set_title("Early heating (Q1 ends at 0.5 h)")
    axes[1].set_title("Long process")
    for ax in axes:
        ax.set(xlabel="Time (h)", ylabel="Temperature (deg C)")
        ax.grid(alpha=.18)
        ax.legend(fontsize=7, loc="best")
    fig.savefig(output / "temperature_history.png")
    plt.close(fig)

    fig, axes = plt.subplots(1, 2, figsize=(7.0, 2.8), constrained_layout=True)
    for q in ("q23", "q4"):
        data = fields[q]
        for ax in axes:
            ax.plot(data["time_s"] / 3600, data["sample_max_C"], color=colors[q], lw=1.4, label=labels[q])
            ax.plot(data["time_s"][-1] / 3600, data["sample_max_C"][-1], "o", color=colors[q], ms=3)
    for ax in axes:
        ax.axhline(.15, color="#555555", ls=":", lw=1, label="Threshold 0.15")
        ax.set(xlabel="Time (h)", ylabel="Sample max C (kg/kg dry)")
        ax.grid(alpha=.18)
        ax.legend(fontsize=8)
    axes[0].set_title("21 radial samples + actual surface")
    axes[1].set(xlim=(35, 59), ylim=(.14, .35), title="Late stage (same archived samples)")
    fig.savefig(output / "moisture_history.png")
    plt.close(fig)

    fig, axes = plt.subplots(2, 3, figsize=(7.0, 4.3), constrained_layout=True)
    for col, (q, data) in enumerate(fields.items()):
        selected = [100, 600, 1800] if q == "q1" else [14400, 86400, data["time_s"][-1]]
        for t in selected:
            i = int(np.argmin(abs(data["time_s"] - t)))
            for row, key, surface_key in [(0, "temperature_C", "surface_temperature_C"), (1, "moisture_dry_kgkg", "surface_moisture_dry_kgkg")]:
                valid = np.isfinite(data[key][i])
                radius = data["radii_m"][valid] * 100
                values = data[key][i, valid]
                if q == "q4" and data["radius_m"][i] * 100 > radius[-1]:
                    radius = np.append(radius, data["radius_m"][i] * 100)
                    values = np.append(values, data[surface_key][i])
                axes[row, col].plot(radius, values, ".-", lw=1, ms=2.5, label=f"{data['time_s'][i] / 3600:.2f} h")
                axes[row, col].grid(alpha=.18)
                axes[row, col].legend(fontsize=7)
                axes[row, col].set_xlabel("Physical radius (cm)")
        axes[0, col].set_title(labels[q])
    axes[0, 0].set_ylabel("Temperature (deg C)")
    axes[1, 0].set_ylabel("C (kg/kg dry)")
    fig.savefig(output / "radial_profiles.png")
    plt.close(fig)
    evidence["figures"] = [{"path": p.relative_to(BASE).as_posix(), "sha256": hashlib.sha256(p.read_bytes()).hexdigest()} for p in sorted(output.glob("*.png"))]
    (output / "figure_data.json").write_text(json.dumps(evidence, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return evidence


if __name__ == "__main__":
    main()
