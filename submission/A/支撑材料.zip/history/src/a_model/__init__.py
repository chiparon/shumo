"""Radial transport calculations for problem A."""
