"""Appendices 3/4: coupled radial transport in a material coordinate.

xi=r/R(t), uniform radial material contraction, fixed length and conserved dry
mass. Empirical rho is an effective thermal coefficient, not conserved dry
mass density. No latent heat, radiation or end-face transport is included.
"""

from dataclasses import dataclass

import numpy as np
from scipy.integrate import solve_ivp
from scipy.optimize import brentq
from scipy.sparse import diags, kron, lil_matrix
from scipy.special import expn

from .radial import FloatArray


@dataclass(frozen=True)
class DryingSolution:
    time_s: FloatArray
    radii_m: FloatArray
    radius_m: FloatArray
    temperature_C: FloatArray
    moisture_dry_kgkg: FloatArray
    surface_temperature_C: FloatArray
    surface_moisture_dry_kgkg: FloatArray
    mean_moisture_dry_kgkg: FloatArray
    outward_integral: FloatArray
    final_temperature_C: FloatArray
    final_moisture_dry_kgkg: FloatArray
    diagnostics: dict


def properties(temperature_C, moisture, appendix):
    """Return heat capacity, conductivity, thermal mobility and moisture activation.

    D(C,T)=mobility(T)*exp(-activation/C); its moisture dependence is
    integrated into the Kirchhoff potential rather than endpoint-averaged.
    """
    if np.any(moisture <= 0) or np.any(temperature_C <= -273.15):
        raise ValueError("Constitutive laws require positive C and absolute T; states are not clipped")
    fraction = moisture / (moisture + 1.0)
    if appendix == 3:
        rho = 650.0 + 128.0 * moisture
        cp = 1450.0 + 2736.0 * fraction
        conductivity = 0.21 + 0.38 * fraction
        prefactor, activation = 2.4e-3, 0.45
    elif appendix == 4:
        rho = 760.0 + 90.0 * moisture
        cp = 1850.0 + 2150.0 * fraction
        conductivity = 0.12 + 0.20 * fraction
        prefactor, activation = 4.2e-4, 0.30
    else:
        raise ValueError("Long-process model requires appendix 3 or 4")
    log_mobility = np.log(prefactor) - 3850.0 / (temperature_C + 273.15)
    if not np.all(np.isfinite(log_mobility)) or np.any(log_mobility - activation / moisture < np.log(np.nextafter(0.0, 1.0))):
        raise ValueError("Constitutive diffusion is nonfinite or underflowed")
    return rho * cp, conductivity, np.exp(log_mobility), activation


def moisture_potential_difference(moisture, activation):
    """Stable adjacent differences of Phi(C)=C*E_2(activation/C).

    Phi'=exp(-activation/C). Nearby states use two-point Gaussian
    quadrature to avoid cancellation, not a concentration floor or clipping.
    """
    left, right = moisture[:-1], moisture[1:]
    delta = right - left
    magnitude = np.abs(delta)
    nearby = (magnitude <= 1e-3 * np.minimum(left, right)) & (activation * magnitude <= 1e-3 * left * right)
    result = np.empty_like(delta)
    middle = (left[nearby] + right[nearby]) * 0.5
    offset = delta[nearby] / np.sqrt(12.0)
    result[nearby] = 0.5 * (np.exp(-activation / (middle - offset)) + np.exp(-activation / (middle + offset))) * delta[nearby]
    far_left, far_right = left[~nearby], right[~nearby]
    result[~nearby] = far_right * expn(2, activation / far_right) - far_left * expn(2, activation / far_left)
    return result


def solve_drying(
    environment: FloatArray,
    *,
    appendix: int = 3,
    radius_observations: FloatArray | None = None,
    environment_tail: str = "last",
    radius_tail: str = "error",
    intervals: int = 400,
    output_step_s: float = 60.0,
    max_time_s: float = 168 * 3600.0,
    rtol: float = 1e-8,
    atol: float = 1e-10,
    heat_transfer: float = 25.0,
    mass_transfer: float = 8e-7,
) -> DryingSolution:
    """Return sampled fields through the first strict full-domain C<0.15 event.

    Sampling occurs in bounded chunks; a full grid x every-output-second array
    is never retained. Domain-exterior sampled entries are NaN, for blank export.
    An unreached event is reported, never replaced by the integration horizon.
    """
    environment = np.asarray(environment, dtype=float)
    if environment.ndim != 2 or environment.shape[1] != 3 or len(environment) < 2:
        raise ValueError("Environment requires time/temperature/moisture columns")
    if not np.all(np.isfinite(environment)) or np.any(np.diff(environment[:, 0]) <= 0):
        raise ValueError("Environment must be finite with strictly increasing times")
    if environment[0, 0] > 0 or np.any(environment[:, 2] <= 0):
        raise ValueError("Environment must cover zero and have positive effective moisture")
    if environment_tail not in ("last", "last_hour_mean") or radius_tail not in ("error", "last"):
        raise ValueError("Unknown explicit continuation policy")
    if not isinstance(intervals, (int, np.integer)) or intervals < 2:
        raise ValueError("At least two radial intervals are required")
    if not all(np.isfinite(v) and v > 0 for v in (output_step_s, max_time_s, rtol, atol)):
        raise ValueError("Time horizon, output interval and tolerances must be positive")
    if not all(np.isfinite(v) and v >= 0 for v in (heat_transfer, mass_transfer)):
        raise ValueError("Surface transfer coefficients must be nonnegative")
    moving = radius_observations is not None
    limit = max_time_s
    if moving:
        radius_observations = np.asarray(radius_observations, dtype=float)
        if radius_observations.ndim != 2 or radius_observations.shape[1] != 2 or len(radius_observations) < 2:
            raise ValueError("Radius observations require time and radius in metres")
        if not np.all(np.isfinite(radius_observations)) or np.any(np.diff(radius_observations[:, 0]) <= 0) or np.any(radius_observations[:, 1] <= 0):
            raise ValueError("Radius observations must be positive and strictly ordered in time")
        if radius_observations[0, 0] > 0 or not np.isclose(radius_observations[0, 1], 0.02):
            raise ValueError("Radius observations must start at the prescribed 0.02 m cylinder")
        if radius_tail == "error":
            limit = min(limit, radius_observations[-1, 0])
    else:
        radius_observations = np.array([[0.0, 0.02], [limit, 0.02]])
    end_observed = environment[-1, 0]
    tail_values = environment[-1, 1:] if environment_tail == "last" else environment[environment[:, 0] >= end_observed - 3600.0, 1:].mean(axis=0)
    xi = np.linspace(0.0, 1.0, intervals + 1)
    faces = (xi[:-1] + xi[1:]) * 0.5
    volumes = np.diff(np.r_[0.0, faces, 1.0] ** 2) * 0.5
    geometric_conductance = faces * intervals
    count = len(xi)
    # Interleaved (T,C) nodes give block-tridiagonal physical dependencies.
    adjacency = diags([np.ones(count - 1), np.ones(count), np.ones(count - 1)], [-1, 0, 1], format="csc")
    sparsity = lil_matrix((2 * count + 1, 2 * count + 1), dtype=bool)
    sparsity[:-1, :-1] = kron(adjacency, np.ones((2, 2), dtype=bool), format="csc")
    sparsity[-1, -2] = True
    sparsity = sparsity.tocsc()
    state = np.empty(2 * count + 1)
    state[:-1:2] = 28.0
    state[1:-1:2] = 2.55
    state[-1] = 0.0
    tolerances = np.full(state.size, atol)
    tolerances[-1] = atol * volumes.sum()
    radii_out = np.linspace(0.0, 0.02, 21)
    all_times, all_radii, all_heat, all_moisture = [], [], [], []
    all_surface_heat, all_surface_moisture, all_mean, all_outward = [], [], [], []
    diagnostics = {"nfev": 0, "njev": 0, "nlu": 0, "maximum_relative_water_balance_residual": 0.0, "maximum_radial_moisture_increase": 0.0, "maximum_temporal_maximum_increase": 0.0}
    event = None
    minimum_moisture, maximum_moisture = 2.55, 2.55
    minimum_temperature, maximum_temperature = 28.0, 28.0
    knots = np.unique(np.r_[0.0, environment[:, 0], radius_observations[:, 0], np.arange(0.0, limit, 3600.0), limit])
    knots = knots[(knots >= 0) & (knots <= limit)]
    next_output = 0

    for start, end in zip(knots[:-1], knots[1:]):
        if start >= end_observed:
            boundary_start, slope = tail_values, np.zeros(2)
        else:
            boundary_start = np.array([np.interp(start, environment[:, 0], environment[:, col]) for col in (1, 2)])
            boundary_end = np.array([np.interp(end, environment[:, 0], environment[:, col]) for col in (1, 2)])
            slope = (boundary_end - boundary_start) / (end - start)

        def rhs(time, current):
            temperature, concentration = current[:-1:2], current[1:-1:2]
            capacity, conductivity, mobility, activation = properties(temperature, concentration, appendix)
            radius = np.interp(time, radius_observations[:, 0], radius_observations[:, 1])
            boundary = boundary_start + slope * (time - start)
            thermal_face = 2 * conductivity[:-1] * conductivity[1:] / (conductivity[:-1] + conductivity[1:])
            moisture_face = 2 * mobility[:-1] * mobility[1:] / (mobility[:-1] + mobility[1:])
            heat_flow = geometric_conductance * thermal_face * np.diff(temperature)
            water_flow = geometric_conductance * moisture_face * moisture_potential_difference(concentration, activation)
            heat_out = radius * heat_transfer * (temperature[-1] - boundary[0])
            water_out = radius * mass_transfer * (concentration[-1] - boundary[1])
            result = np.empty_like(current)
            heat_rate, water_rate = result[:-1:2], result[1:-1:2]
            heat_rate[:-1], water_rate[:-1] = heat_flow, water_flow
            heat_rate[-1], water_rate[-1] = -heat_out, -water_out
            heat_rate[1:] -= heat_flow
            water_rate[1:] -= water_flow
            factor = 1.0 / (volumes * radius**2)
            heat_rate *= factor / capacity
            water_rate *= factor
            result[-1] = water_out / radius**2
            return result

        # SciPy's default explicit initial-step probe can leave the C>0 domain
        # on fine grids: its RMS norm dilutes a large surface-only derivative.
        # Supply a scale-based first step bounded by positive Euler predictors.
        initial_rate = rhs(start, state)
        scale = tolerances + rtol * np.abs(state)
        d0 = np.linalg.norm(state / scale)
        d1 = np.linalg.norm(initial_rate / scale)
        suggested = 1e-6 if min(d0, d1) < 1e-5 else 0.01 * d0 / d1
        positive_state = state[:-1].copy()
        positive_state[::2] += 273.15
        falling = initial_rate[:-1] < 0
        positive_limit = np.min(positive_state[falling] / -initial_rate[:-1][falling], initial=np.inf)
        first_step = min(end - start, suggested, 0.1 * positive_limit)
        solution = solve_ivp(rhs, (start, end), state, method="BDF", first_step=first_step, dense_output=True, jac_sparsity=sparsity, rtol=rtol, atol=tolerances)
        if not solution.success or not np.all(np.isfinite(solution.y)):
            raise RuntimeError(f"Drying integration failed in [{start}, {end}] s: {solution.message}")
        for name in ("nfev", "njev", "nlu"):
            diagnostics[name] += getattr(solution, name)
        concentration_states = solution.y[1:-1:2]
        maxima = concentration_states.max(axis=0)
        diagnostics["maximum_temporal_maximum_increase"] = max(diagnostics["maximum_temporal_maximum_increase"], float(np.max(np.diff(maxima), initial=0.0)))
        cutoff = end
        crossed = np.flatnonzero(maxima < 0.15)
        if crossed.size:
            first = int(crossed[0])
            if first == 0:
                raise RuntimeError("Unexpected previously crossed drying event")
            lo, hi = solution.t[first - 1], solution.t[first]
            criterion = lambda time: float(solution.sol(time)[1:-1:2].max() - 0.15)
            crossing = brentq(criterion, lo, hi, xtol=1e-7)
            while hi - lo > 5e-4:
                middle = (lo + hi) * 0.5
                if criterion(middle) < 0:
                    hi = middle
                else:
                    lo = middle
            cutoff = float(np.ceil(hi * 1e4) / 1e4)
            if cutoff > end:
                cutoff = hi
            event = {"crossing_time_s": float(crossing), "strict_end_time_s": cutoff, "bracket_lower_s": float(lo), "bracket_upper_s": cutoff, "bracket_width_s": float(cutoff - lo), "lower_max_moisture": criterion(lo) + 0.15, "upper_max_moisture": criterion(cutoff) + 0.15}
            if event["upper_max_moisture"] >= 0.15:
                raise RuntimeError("Drying endpoint does not satisfy the strict full-domain criterion")
        last_output = int(np.floor(cutoff / output_step_s))
        requested = np.arange(next_output, last_output + 1, dtype=float) * output_step_s
        next_output = last_output + 1
        if event is not None or end == limit:
            if not requested.size or requested[-1] != cutoff:
                requested = np.r_[requested, cutoff]
        for begin in range(0, requested.size, 64):
            chunk_times = requested[begin:begin + 64]
            chunk = solution.sol(chunk_times)
            thermal, wet = chunk[:-1:2], chunk[1:-1:2]
            radius_values = np.interp(chunk_times, radius_observations[:, 0], radius_observations[:, 1])
            heat_sample = np.stack([np.interp(radii_out / radius, xi, row, right=np.nan) for radius, row in zip(radius_values, thermal.T)])
            wet_sample = np.stack([np.interp(radii_out / radius, xi, row, right=np.nan) for radius, row in zip(radius_values, wet.T)])
            mean = (volumes @ wet) / volumes.sum()
            residual = mean * volumes.sum() - 2.55 * volumes.sum() + chunk[-1]
            diagnostics["maximum_relative_water_balance_residual"] = max(diagnostics["maximum_relative_water_balance_residual"], float(np.max(np.abs(residual)) / (2.55 * volumes.sum())))
            diagnostics["maximum_radial_moisture_increase"] = max(diagnostics["maximum_radial_moisture_increase"], float(np.max(np.diff(wet, axis=0), initial=0.0)))
            minimum_moisture, maximum_moisture = min(minimum_moisture, float(wet.min())), max(maximum_moisture, float(wet.max()))
            minimum_temperature, maximum_temperature = min(minimum_temperature, float(thermal.min())), max(maximum_temperature, float(thermal.max()))
            all_times.append(chunk_times)
            all_radii.append(radius_values)
            all_heat.append(heat_sample)
            all_moisture.append(wet_sample)
            all_surface_heat.append(thermal[-1].copy())
            all_surface_moisture.append(wet[-1].copy())
            all_mean.append(mean)
            all_outward.append(chunk[-1].copy())
        state = solution.sol(cutoff) if event is not None else solution.y[:, -1]
        if event is not None:
            break
    if minimum_moisture <= 0:
        raise RuntimeError("Nonpositive moisture was computed; no clipping was applied")
    diagnostics.update({
        "status": "drying_event_reached" if event is not None else "radius_coverage_exhausted" if moving and radius_tail == "error" and limit < max_time_s else "time_horizon_exhausted",
        "appendix": appendix, "moving_radius": moving, "intervals": intervals, "rtol": rtol, "atol": atol,
        "environment_tail": environment_tail, "environment_tail_values": tail_values.tolist(), "environment_observed_end_s": float(end_observed),
        "radius_tail": radius_tail if moving else "not_applicable", "event": event,
        "minimum_moisture": minimum_moisture, "maximum_moisture": maximum_moisture,
        "minimum_temperature_C": minimum_temperature, "maximum_temperature_C": maximum_temperature,
        "heat_transfer_W_m2K": heat_transfer, "mass_transfer_m_s": mass_transfer,
        "water_balance": "sum(C_i * integral_CV(xi dxi)) + integral(hm/R*(Cs-Ceq) dt) is constant; conserved dry-mass prefactor cancels",
        "water_face_flux": "Kirchhoff Phi(C)=C*E2(a/C), harmonic thermal mobility g(T); no endpoint averaging of exp(-a/C)",
        "thermal_density": "Empirical rho(C) only supplies effective heat storage; not used as conserved dry density",
        "physical_review_status": "pending_human_team_review",
    })
    return DryingSolution(np.concatenate(all_times), radii_out, np.concatenate(all_radii), np.concatenate(all_heat), np.concatenate(all_moisture), np.concatenate(all_surface_heat), np.concatenate(all_surface_moisture), np.concatenate(all_mean), np.concatenate(all_outward), state[:-1:2].copy(), state[1:-1:2].copy(), diagnostics)
