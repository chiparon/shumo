"""Appendix 2 model, with the provisional effective air-to-solid closure."""

import numpy as np

from .radial import FloatArray, RadialSolution, solve_radial

RADIUS_M = 0.02
DENSITY_KG_M3 = 820.0
HEAT_CAPACITY_J_KGK = 2600.0
CONDUCTIVITY_W_MK = 0.36
HEAT_TRANSFER_W_M2K = 25.0
MASS_TRANSFER_M_S = 8e-7
INITIAL_TEMPERATURE_C = 28.0
INITIAL_MOISTURE_DRY_KGKG = 2.55
PAPER_TIMES_S = (100, 300, 600, 900, 1200, 1500, 1800)
PAPER_RADII_CM = (0.0, 0.5, 1.0, 1.5, 2.0)

ASSUMPTIONS = {
    "physical_review_status": "pending_team_review",
    "geometry": "Fixed radius 0.02 m; axisymmetric radial transport, no end effects",
    "initial_state": "Uniform 28 degC and 2.55 kg water / kg dry material",
    "air_to_solid": "Attachment air moisture is used numerically as effective C_eq; this is not an identified sorption law",
    "omissions": ["explicit evaporation latent heat", "radiation", "deformation"],
    "environment": "Piecewise-linear measured input; no extrapolation in Q1",
    "moisture_balance": "Effective Fick equation with constant dry-material weighting; rho is not inserted into the moisture flux",
}


def moisture_diffusivity(moisture: FloatArray) -> FloatArray:
    if not np.all(np.isfinite(moisture)) or np.any(moisture <= 0):
        raise ValueError("Appendix 2 diffusivity requires strictly positive finite dry-basis moisture")
    return 7e-9 * np.exp(-0.89 / moisture)


def solve_q1(
    environment: FloatArray,
    *,
    intervals: int = 3200,
    rtol: float = 1e-9,
    atol: float = 1e-11,
) -> tuple[RadialSolution, RadialSolution]:
    """Input columns: time (s), air temperature (degC), air moisture (kg/kg)."""
    environment = np.asarray(environment, dtype=float)
    if environment.ndim != 2 or environment.shape[1] != 3:
        raise ValueError("Environment must have time, temperature and moisture columns")
    if np.any(environment[:, 2] <= 0):
        raise ValueError("Effective equilibrium moisture must be positive")
    common = {
        "radius_m": RADIUS_M,
        "intervals": intervals,
        "environment_times_s": environment[:, 0],
        "output_times_s": np.arange(1801, dtype=float),
        "rtol": rtol,
        "atol": atol,
    }
    heat = solve_radial(
        diffusivity=CONDUCTIVITY_W_MK / (DENSITY_KG_M3 * HEAT_CAPACITY_J_KGK),
        surface_transfer_m_s=HEAT_TRANSFER_W_M2K / (DENSITY_KG_M3 * HEAT_CAPACITY_J_KGK),
        initial_value=INITIAL_TEMPERATURE_C,
        environment_values=environment[:, 1],
        **common,
    )
    moisture = solve_radial(
        diffusivity=moisture_diffusivity,
        surface_transfer_m_s=MASS_TRANSFER_M_S,
        initial_value=INITIAL_MOISTURE_DRY_KGKG,
        environment_values=environment[:, 2],
        **common,
    )
    if np.any(moisture.values <= 0):
        raise RuntimeError("Computed moisture is not positive; no clipping has been applied")
    return heat, moisture
