"""Fixed cylinder: u_t = div(a grad u), -a u_r(R) = b (u_s - u_air).

Node-centred control volumes include both r=0 and r=R. Their weights are
integrals of r dr; the common factor 2*pi*length is omitted throughout.
"""

from collections.abc import Callable
from dataclasses import dataclass

import numpy as np
from numpy.typing import NDArray
from scipy.integrate import solve_ivp
from scipy.sparse import diags

FloatArray = NDArray[np.float64]


@dataclass(frozen=True)
class RadialSolution:
    time_s: FloatArray
    radius_m: FloatArray
    values: FloatArray
    volume_weights: FloatArray
    outward_integral: FloatArray
    diagnostics: dict

    def sample(self, radii_m: FloatArray) -> FloatArray:
        """Interpolate spatially, without extrapolating beyond the cylinder."""
        radii = np.asarray(radii_m, dtype=float)
        if radii.ndim != 1 or not np.all(np.isfinite(radii)):
            raise ValueError("Output radii must be a finite one-dimensional array")
        if np.any(radii < 0) or np.any(radii > self.radius_m[-1]):
            raise ValueError("Output radius lies outside the physical cylinder")
        return np.stack([np.interp(radii, self.radius_m, row) for row in self.values])


def solve_radial(
    *,
    radius_m: float,
    intervals: int,
    diffusivity: float | Callable[[FloatArray], FloatArray],
    surface_transfer_m_s: float,
    initial_value: float,
    environment_times_s: FloatArray,
    environment_values: FloatArray,
    output_times_s: FloatArray,
    rtol: float = 1e-9,
    atol: float = 1e-11,
) -> RadialSolution:
    """Integrate one scalar field with piecewise-linear measured forcing.

    a can depend on the local field; positive nodal coefficients are harmonically
    averaged at interior faces. No clipping of states or extrapolation of forcing
    is performed. The final state component integrates outward boundary transport.
    """
    times = np.asarray(output_times_s, dtype=float)
    env_times = np.asarray(environment_times_s, dtype=float)
    env_values = np.asarray(environment_values, dtype=float)
    if not isinstance(intervals, (int, np.integer)) or intervals < 2:
        raise ValueError("At least two integer radial intervals are required")
    if not np.isfinite(radius_m) or radius_m <= 0:
        raise ValueError("Cylinder radius must be finite and positive")
    if not np.isfinite(surface_transfer_m_s) or surface_transfer_m_s < 0:
        raise ValueError("Surface transfer must be finite and nonnegative")
    if not np.isfinite(initial_value):
        raise ValueError("Initial value must be finite")
    if not np.isfinite(rtol) or not np.isfinite(atol) or rtol <= 0 or atol <= 0:
        raise ValueError("Integration tolerances must be finite and positive")
    if times.ndim != 1 or times.size < 2 or not np.all(np.isfinite(times)):
        raise ValueError("Provide finite output times including zero and an end time")
    if times[0] != 0 or np.any(np.diff(times) <= 0):
        raise ValueError("Output times must strictly increase from zero")
    if env_times.ndim != 1 or env_values.shape != env_times.shape or env_times.size < 2:
        raise ValueError("Environment requires matching one-dimensional time/value arrays")
    if not np.all(np.isfinite(env_times)) or not np.all(np.isfinite(env_values)):
        raise ValueError("Environment contains nonfinite observations")
    if np.any(np.diff(env_times) <= 0):
        raise ValueError("Environment observation times must strictly increase")
    if env_times[0] > 0 or env_times[-1] < times[-1]:
        raise ValueError("Environment does not cover the requested integration horizon")

    radii = np.linspace(0.0, radius_m, intervals + 1)
    faces = (radii[:-1] + radii[1:]) * 0.5
    edges = np.concatenate(([0.0], faces, [radius_m]))
    volumes = np.diff(edges**2) * 0.5
    inverse_volumes = 1.0 / volumes
    geometric_conductance = faces / (radius_m / intervals)
    surface_factor = radius_m * surface_transfer_m_s
    count = radii.size
    nonlinear = callable(diffusivity)
    if nonlinear:
        constant_conductance = None
        # Only the adjacency pattern is used for finite-difference Jacobians.
        jac_conductance = geometric_conductance
    else:
        coefficient = float(diffusivity)
        if not np.isfinite(coefficient) or coefficient <= 0:
            raise ValueError("Diffusivity must be finite and positive")
        constant_conductance = geometric_conductance * coefficient
        jac_conductance = constant_conductance

    diagonal = np.zeros(count + 1)
    diagonal[:-2] -= jac_conductance * inverse_volumes[:-1]
    diagonal[1:-1] -= jac_conductance * inverse_volumes[1:]
    diagonal[-2] -= surface_factor * inverse_volumes[-1]
    jacobian = diags(
        [
            np.concatenate((jac_conductance * inverse_volumes[1:], [surface_factor])),
            diagonal,
            np.concatenate((jac_conductance * inverse_volumes[:-1], [0.0])),
        ],
        offsets=(-1, 0, 1),
        shape=(count + 1, count + 1),
        format="csc",
    )
    jac_options = {"jac_sparsity": jacobian != 0} if nonlinear else {"jac": jacobian}
    state = np.concatenate((np.full(count, initial_value), [0.0]))
    values = np.empty((times.size, count))
    outward_integral = np.empty(times.size)
    values[0] = initial_value
    outward_integral[0] = 0.0
    absolute_tolerances = np.concatenate((np.full(count, atol), [atol * volumes.sum()]))
    breaks = np.concatenate(([0.0], env_times[(env_times > 0) & (env_times < times[-1])], [times[-1]]))
    boundary_values = np.interp(breaks, env_times, env_values)
    counters = {"nfev": 0, "njev": 0, "nlu": 0}

    for segment, (start, end) in enumerate(zip(breaks[:-1], breaks[1:])):
        boundary_start = boundary_values[segment]
        boundary_slope = (boundary_values[segment + 1] - boundary_start) / (end - start)

        def rhs(time, current):
            field = current[:-1]
            if nonlinear:
                coefficients = np.asarray(diffusivity(field), dtype=float)
                if coefficients.shape != field.shape or not np.all(np.isfinite(coefficients)) or np.any(coefficients <= 0):
                    raise ValueError("Local diffusivity must remain finite and positive; states are not clipped")
                face_coefficients = 2.0 * coefficients[:-1] * coefficients[1:] / (coefficients[:-1] + coefficients[1:])
                conductance = geometric_conductance * face_coefficients
            else:
                conductance = constant_conductance
            interior_flow = conductance * np.diff(field)
            boundary = boundary_start + boundary_slope * (time - start)
            outward_flow = surface_factor * (field[-1] - boundary)
            derivative = np.empty_like(current)
            derivative[:-2] = interior_flow
            derivative[-2] = -outward_flow
            derivative[1:-1] -= interior_flow
            derivative[:-1] *= inverse_volumes
            derivative[-1] = outward_flow
            return derivative

        first = np.searchsorted(times, start, side="right")
        last = np.searchsorted(times, end, side="right")
        requested = times[first:last]
        evaluation_times = requested if requested.size and requested[-1] == end else np.append(requested, end)
        solution = solve_ivp(
            rhs,
            (start, end),
            state,
            method="BDF",
            t_eval=evaluation_times,
            rtol=rtol,
            atol=absolute_tolerances,
            **jac_options,
        )
        if not solution.success:
            raise RuntimeError(f"Radial integration failed in [{start}, {end}] s: {solution.message}")
        if not np.all(np.isfinite(solution.y)):
            raise RuntimeError("Radial integration produced nonfinite states")
        values[first:last] = solution.y[:-1, :requested.size].T
        outward_integral[first:last] = solution.y[-1, :requested.size]
        state = solution.y[:, -1]
        for name in counters:
            counters[name] += getattr(solution, name)

    inventory = values @ volumes
    balance_residual = inventory - initial_value * volumes.sum() + outward_integral
    scale = max(abs(initial_value), float(np.max(np.abs(boundary_values))), 1.0) * volumes.sum()
    diagnostics = {
        "method": "node-centred radial finite volume / BDF",
        "intervals": intervals,
        "spacing_m": radius_m / intervals,
        "forcing_segments": len(breaks) - 1,
        "rtol": rtol,
        "atol_field": atol,
        "minimum_value": float(values.min()),
        "maximum_value": float(values.max()),
        "final_volume_mean": float(inventory[-1] / volumes.sum()),
        "maximum_balance_residual": float(np.max(np.abs(balance_residual))),
        "maximum_relative_balance_residual": float(np.max(np.abs(balance_residual)) / scale),
        "balance_definition": "sum(u_i * integral_CV(r dr)) - initial_inventory + integral(R*b*(u_surface-u_air) dt)",
        "balance_scope": "Discrete transport identity; not an independent validation of the physical closure",
        **counters,
    }
    return RadialSolution(times, radii, values, volumes, outward_integral, diagnostics)
