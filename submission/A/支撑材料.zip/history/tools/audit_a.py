"""Read-only audit of problem A workbooks; no model formulas or extrapolation."""

import argparse
import hashlib
import json
import math
import posixpath
import re
import statistics
from pathlib import Path
from xml.etree import ElementTree as ET
from zipfile import BadZipFile, ZipFile


ROOT = Path(__file__).resolve().parents[1]
INPUT_DIR = ROOT / "stems" / "A题" / "附件"
MAIN_NS = "http://schemas.openxmlformats.org/spreadsheetml/2006/main"
REL_NS = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"
NS = {"m": MAIN_NS}
CELL_REF = re.compile(r"([A-Z]+)([1-9][0-9]*)\Z")
FIELDS = {
    "environment": {
        "A": {"name": "time", "header": "时间", "unit": "s", "constraint": "nonnegative"},
        "B": {"name": "temperature", "header": "温度", "unit": "°C", "constraint": "finite"},
        "C": {"name": "moisture_concentration", "header": "水分浓度", "unit": "kg/kg", "constraint": "positive"},
    },
    "radius": {
        "A": {"name": "time", "header": "时间", "unit": "s", "constraint": "nonnegative"},
        "B": {"name": "radius", "header": "半径", "unit": "cm", "constraint": "positive"},
    },
}


def issue(issues, code, source, message, **details):
    issues.append({"code": code, "source": source, "message": message, **details})


def column_number(column):
    number = 0
    for char in column:
        number = number * 26 + ord(char) - ord("A") + 1
    return number


def rich_text(element):
    if element is None:
        return ""
    return "".join(node.text or "" for node in element.findall("m:t", NS)) + "".join(
        node.text or "" for node in element.findall("m:r/m:t", NS)
    )


def package_target(target):
    path = posixpath.normpath(target.lstrip("/") if target.startswith("/") else "xl/" + target)
    if path.startswith("../") or path == "..":
        raise ValueError("Workbook relationship escapes the package")
    return path


def cell_value(cell, strings):
    kind = cell.get("t", "n")
    if kind == "inlineStr":
        return rich_text(cell.find("m:is", NS))
    raw = cell.findtext("m:v", namespaces=NS)
    if raw is None or raw == "":
        return None
    if kind == "s":
        index = int(raw)
        if not 0 <= index < len(strings):
            raise ValueError("Invalid shared-string index: " + raw)
        return strings[index]
    if kind in ("str", "d"):
        return raw
    if kind == "b":
        if raw not in ("0", "1"):
            raise ValueError("Invalid boolean: " + raw)
        return raw == "1"
    if kind == "e":
        raise ValueError("Excel error cell: " + raw)
    if kind != "n":
        raise ValueError("Unsupported cell type: " + kind)
    value = float(raw)
    if not math.isfinite(value):
        raise ValueError("Nonfinite numeric value: " + raw)
    return int(raw) if re.fullmatch(r"[+-]?[0-9]+", raw) else value


def read_workbook(path, errors):
    """Parse only sheet relationships, cell coordinates and stored cell values."""
    source = path.relative_to(ROOT).as_posix()
    entry = {"path": source, "sha256": None, "sheets": []}
    try:
        entry["sha256"] = hashlib.sha256(path.read_bytes()).hexdigest()
        with ZipFile(path) as archive:
            workbook = ET.fromstring(archive.read("xl/workbook.xml"))
            relationships = ET.fromstring(archive.read("xl/_rels/workbook.xml.rels"))
            rels = {rel.attrib["Id"]: rel for rel in relationships}
            strings = []
            for rel in relationships:
                if rel.get("Type", "").endswith("/sharedStrings"):
                    if rel.get("TargetMode") == "External":
                        raise ValueError("External shared strings are not supported")
                    string_root = ET.fromstring(archive.read(package_target(rel.attrib["Target"])))
                    strings = [rich_text(si) for si in string_root.findall("m:si", NS)]
            sheet_nodes = workbook.findall("m:sheets/m:sheet", NS)
            if not sheet_nodes:
                raise ValueError("Workbook has no sheets")
            for sheet_node in sheet_nodes:
                name = sheet_node.attrib["name"]
                rel = rels[sheet_node.attrib["{" + REL_NS + "}id"]]
                if rel.get("TargetMode") == "External" or not rel.get("Type", "").endswith("/worksheet"):
                    raise ValueError("Expected an internal worksheet relationship: " + name)
                member = package_target(rel.attrib["Target"])
                tree = ET.fromstring(archive.read(member))
                dimension = tree.find("m:dimension", NS)
                sheet = {
                    "name": name,
                    "xml_part": member,
                    "declared_dimension": dimension.get("ref") if dimension is not None else None,
                    "rows": {},
                    "xml_row_count": 0,
                    "xml_cell_count": 0,
                    "explicit_blank_cell_count": 0,
                    "formula_cells": [],
                }
                entry["sheets"].append(sheet)
                seen_rows, seen_cells = set(), set()
                for row in tree.findall("m:sheetData/m:row", NS):
                    sheet["xml_row_count"] += 1
                    row_number = int(row.attrib["r"])
                    if not 1 <= row_number <= 1048576:
                        raise ValueError("Invalid row coordinate: " + str(row_number))
                    if row_number in seen_rows:
                        issue(errors, "duplicate_xml_row", source, "Duplicate worksheet row", sheet=name, row=row_number)
                    seen_rows.add(row_number)
                    for cell in row.findall("m:c", NS):
                        sheet["xml_cell_count"] += 1
                        ref = cell.attrib["r"]
                        match = CELL_REF.fullmatch(ref)
                        if not match or int(match[2]) != row_number or column_number(match[1]) > 16384:
                            raise ValueError("Invalid or inconsistent cell coordinate: " + ref)
                        if ref in seen_cells:
                            issue(errors, "duplicate_xml_cell", source, "Duplicate cell coordinate", sheet=name, cell=ref)
                            continue
                        seen_cells.add(ref)
                        formula = cell.find("m:f", NS)
                        if formula is not None:
                            sheet["formula_cells"].append(ref)
                        try:
                            value = cell_value(cell, strings)
                        except (ValueError, OverflowError) as exc:
                            issue(errors, "invalid_cell", source, str(exc), sheet=name, cell=ref)
                            value = None
                        if value is None or value == "":
                            sheet["explicit_blank_cell_count"] += 1
                            if formula is None:
                                continue
                        sheet["rows"].setdefault(row_number, {})[match[1]] = value
    except (OSError, BadZipFile, ET.ParseError, KeyError, ValueError, OverflowError) as exc:
        issue(errors, "workbook_read_error", source, str(exc))
    return entry


def row_record(number, cells):
    return {"row": number, "cells": {col + str(number): cells[col] for col in sorted(cells, key=column_number)}}


def sheet_summary(sheet):
    rows = sheet["rows"]
    numbers = sorted(rows)
    columns = sorted({col for cells in rows.values() for col in cells}, key=column_number)
    first = row_record(numbers[0], rows[numbers[0]]) if numbers else None
    last = row_record(numbers[-1], rows[numbers[-1]]) if numbers else None
    return {
        key: sheet[key] for key in (
            "name", "xml_part", "declared_dimension", "xml_row_count", "xml_cell_count",
            "explicit_blank_cell_count", "formula_cells",
        )
    } | {
        "actual_nonempty_row_count": len(numbers),
        "actual_nonempty_cell_count": sum(len(cells) for cells in rows.values()),
        "actual_nonempty_row_numbers": numbers,
        "actual_nonempty_bounds": {
            "first_row": numbers[0], "last_row": numbers[-1],
            "first_column": columns[0], "last_column": columns[-1],
        } if numbers else None,
        "first_nonempty_row": first,
        "last_nonempty_row": last,
        "header_values": row_record(1, rows.get(1, {}))["cells"],
    }


def numeric(value):
    return type(value) in (int, float) and math.isfinite(value)


def summary(values):
    return {"count": len(values), "min": min(values), "max": max(values)} if values else {"count": 0, "min": None, "max": None}


def audit_table(entry, kind, errors, warnings):
    fields = FIELDS[kind]
    source = entry["path"]
    result = {"path": source, "fields": fields, "sheets": [sheet_summary(s) for s in entry["sheets"]]}
    if len(entry["sheets"]) != 1:
        issue(errors, "required_sheet_count", source, "Required data workbook must have exactly one sheet")
        return result
    sheet = entry["sheets"][0]
    rows = sheet["rows"]
    headers = rows.get(1, {})
    for col, field in fields.items():
        if headers.get(col) != field["header"]:
            issue(errors, "header_mismatch", source, "Unexpected required header", cell=col + "1", expected=field["header"], actual=headers.get(col))
    extra_headers = sorted(set(headers) - set(fields), key=column_number)
    if extra_headers:
        issue(errors, "extra_headers", source, "Unexpected populated header columns", columns=extra_headers)
    if sheet["formula_cells"]:
        issue(errors, "required_formula_cells", source, "Required observations must be stored values; formulas are not evaluated", cells=sheet["formula_cells"])
    data_numbers = sorted(number for number in rows if number > 1)
    result["data_rows"] = [row_record(number, rows[number]) for number in data_numbers]
    result["populated_data_row_count"] = len(data_numbers)
    missing_rows = sorted(set(range(2, data_numbers[-1] + 1)) - set(data_numbers)) if data_numbers else []
    result["missing_row_numbers"] = missing_rows
    if missing_rows:
        issue(errors, "missing_data_rows", source, "Unpopulated rows within required data range", rows=missing_rows)
    if not data_numbers:
        issue(errors, "empty_required_data", source, "No populated observations")
    missing_cells, invalid_cells, valid_rows = [], [], []
    for number in data_numbers:
        cells = rows[number]
        extra_columns = sorted(set(cells) - set(fields), key=column_number)
        if extra_columns:
            issue(errors, "extra_data_columns", source, "Unexpected populated data columns", row=number, columns=extra_columns)
        valid = not extra_columns
        for col, field in fields.items():
            value = cells.get(col)
            if value is None or value == "":
                missing_cells.append(col + str(number))
                valid = False
            elif not numeric(value) or (field["constraint"] == "positive" and value <= 0) or (field["constraint"] == "nonnegative" and value < 0):
                invalid_cells.append({"cell": col + str(number), "value": value, "constraint": field["constraint"]})
                valid = False
        if valid:
            valid_rows.append((number, cells))
    result["missing_cells"] = missing_cells
    result["invalid_cells"] = invalid_cells
    result["valid_complete_row_count"] = len(valid_rows)
    if missing_cells:
        issue(errors, "missing_required_cells", source, "Missing required observations", cells=missing_cells)
    if invalid_cells:
        issue(errors, "invalid_required_values", source, "Required values violate field constraints", cells=invalid_cells)
    result["statistics_basis"] = "Only complete, finite rows satisfying field constraints; inspect errors before using statistics."
    result["ranges"] = {field["name"]: {"unit": field["unit"], **summary([cells[col] for _, cells in valid_rows])} for col, field in fields.items()}
    time_groups, row_groups = {}, {}
    for number, cells in valid_rows:
        time_groups.setdefault(cells["A"], []).append(number)
        row_groups.setdefault(tuple(cells[col] for col in fields), []).append(number)
    result["duplicate_times"] = [{"time_s": time, "rows": group} for time, group in time_groups.items() if len(group) > 1]
    result["duplicate_data_rows"] = [group for group in row_groups.values() if len(group) > 1]
    if result["duplicate_times"]:
        issue(errors, "duplicate_times", source, "Duplicate observation times", groups=result["duplicate_times"])
    if result["duplicate_data_rows"]:
        issue(errors, "duplicate_data_rows", source, "Duplicate complete observations", groups=result["duplicate_data_rows"])
    intervals = [{"from_row": before[0], "to_row": after[0], "delta_s": after[1]["A"] - before[1]["A"]} for before, after in zip(valid_rows, valid_rows[1:])]
    deltas = [item["delta_s"] for item in intervals]
    increasing = all(delta > 0 for delta in deltas) if deltas else None
    uniform = all(math.isclose(delta, deltas[0], rel_tol=1e-9, abs_tol=1e-9) for delta in deltas) if deltas else None
    result["sampling"] = {"strictly_increasing": increasing, "uniform": uniform, "interval_s": deltas[0] if uniform else None, "interval_range": summary(deltas), "intervals": intervals}
    if increasing is False:
        issue(errors, "time_not_increasing", source, "Observation times are not strictly increasing")
    if uniform is False:
        issue(warnings, "nonuniform_sampling", source, "Observed sampling intervals are not uniform")
    if len(valid_rows) < 2:
        issue(errors, "insufficient_observations", source, "At least two complete observations are required")
        return result
    first, last = valid_rows[0][1], valid_rows[-1][1]
    times = [cells["A"] for _, cells in valid_rows]
    start, end = min(times), max(times)
    result["coverage"] = {"start_s": start, "end_s": end, "span_s": end - start, "start_h": start / 3600, "end_h": end / 3600}
    if kind == "environment":
        result["coverage"]["covers_q1_0_to_1800_s"] = start <= 0 and end >= 1800
        result["coverage"]["covers_q2_paper_table_0_to_10800_s"] = start <= 0 and end >= 10800
        cutoff = end - 3600
        selected = [(number, cells) for number, cells in valid_rows if cutoff <= cells["A"] <= end]
        result["last_hour"] = {
            "window_start_s": cutoff, "window_end_s": end,
            "endpoint_inclusion": "both", "full_hour_covered": start <= cutoff,
            "row_numbers": [number for number, _ in selected],
            "method": "Unweighted sample mean and population standard deviation (ddof=0); no interpolation or time weighting.",
            "statistics": {},
        }
        for col in ("B", "C"):
            values = [cells[col] for _, cells in selected]
            result["last_hour"]["statistics"][fields[col]["name"]] = {"unit": fields[col]["unit"], **summary(values), "mean": statistics.mean(values), "std_population": statistics.pstdev(values)}
        if end < 48 * 3600:
            issue(warnings, "environment_finite_horizon", source, "环境观测仅到所列末时刻，未覆盖题干所述一般烘干过程的2–3天背景时长；Q3实际终止时刻仍待求，超过观测末时刻的环境输入未给出。此审计不外推，也不假定Q3的具体时长。", observed_end_s=end, contextual_duration_h=[48, 72], q3_end_time_s=None)
    else:
        increments = [{"from_row": before[0], "to_row": after[0], "from_time_s": before[1]["A"], "to_time_s": after[1]["A"], "delta_radius_cm": after[1]["B"] - before[1]["B"]} for before, after in zip(valid_rows, valid_rows[1:])]
        changes = [item["delta_radius_cm"] for item in increments]
        result["radius_changes"] = {
            "nonincreasing": all(delta <= 0 for delta in changes),
            "strictly_decreasing": all(delta < 0 for delta in changes),
            "increasing_interval_count": sum(delta > 0 for delta in changes),
            "unchanged_interval_count": sum(delta == 0 for delta in changes),
            "decreasing_interval_count": sum(delta < 0 for delta in changes),
            "increment_range_cm": summary(changes), "increments": increments,
        }
        if any(delta > 0 for delta in changes):
            issue(warnings, "radius_increase", source, "Observed radius increases in one or more intervals")
        ratio = last["B"] / first["B"]
        result["endpoint_shrinkage"] = {
            "initial_time_s": first["A"], "final_time_s": last["A"],
            "initial_radius_cm": first["B"], "final_radius_cm": last["B"],
            "radius_decrease_cm": first["B"] - last["B"],
            "radius_ratio_final_over_initial": ratio,
            "relative_radius_decrease": 1 - ratio,
            "initial_cross_section_cm2": math.pi * first["B"] ** 2,
            "final_cross_section_cm2": math.pi * last["B"] ** 2,
            "cross_section_ratio_final_over_initial": ratio ** 2,
            "relative_cross_section_decrease": 1 - ratio ** 2,
            "basis": "Cross-section = pi * radius^2; relative decreases are fractions, not percentages. No length or volume change inferred.",
        }
        issue(warnings, "radius_finite_horizon", source, "半径表仅覆盖所列时间区间；末端重复半径不证明后续恒定，也不证明干燥已结束。此审计不外推。", observed_start_s=start, observed_end_s=end)
    return result


def build_audit():
    errors, warnings = [], []
    data_entries = [read_workbook(INPUT_DIR / name, errors) for name in ("附件1.xlsx", "附件2.xlsx")]
    template_entries = [read_workbook(INPUT_DIR / "附件3" / ("result" + str(number) + ".xlsx"), errors) for number in range(1, 5)]
    datasets = {kind: audit_table(entry, kind, errors, warnings) for kind, entry in zip(("environment", "radius"), data_entries)}
    return {
        "schema_version": 1,
        "status": "error" if errors else "ok",
        "scope": "A题附件数据与结果模板的只读审计；不求解模型，不验证或解释经验公式。",
        "definitions": {
            "units_source": "stems/A题/A题.pdf，附录1（附件说明）",
            "input_paths": "Project-relative POSIX paths; SHA256 covers exact workbook bytes.",
            "coordinates": "Original one-based worksheet row numbers and Excel column letters; blank cells are never shifted left.",
            "nonempty": "Stored value other than null/empty string, or a formula cell. Style-only cells are blanks; formula cells are reported and never evaluated.",
            "declared_dimension": "Worksheet XML dimension; may include formatting-only cells, not a data-row count.",
            "data_rows": "All populated rows after row 1, retaining original cell coordinates and values.",
            "ranges": "Count/min/max of complete valid observations, with physical units alongside each field.",
            "sampling": "Differences between consecutive complete valid rows in worksheet row order; uniformity tolerance rel=1e-9, abs=1e-9 s.",
            "last_hour": "Closed interval [maximum observed time - 3600 s, maximum observed time]; mean and population standard deviation over included observations.",
            "template_units": {"column_A_time": "s", "row_1_distance": "cm", "temperature": "°C", "moisture_concentration": "kg/kg"},
            "template_blanks": "Normal empty result cells and literal ellipsis markers are not missing-observation errors; templates are illustrative, not complete grids.",
            "warnings": "Data coverage or observed-pattern limitations, not modeling assumptions or solved drying durations.",
        },
        "inputs": [{"path": entry["path"], "sha256": entry["sha256"]} for entry in data_entries + template_entries],
        "datasets": datasets,
        "templates": [{"path": entry["path"], "sheet_names": [sheet["name"] for sheet in entry["sheets"]], "sheets": [sheet_summary(sheet) for sheet in entry["sheets"]]} for entry in template_entries],
        "warnings": warnings,
        "errors": errors,
    }


def main():
    parser = argparse.ArgumentParser(description="Audit problem A XLSX observations and result templates without modifying inputs.")
    parser.add_argument("--output", type=Path, default=ROOT / "artifacts" / "A" / "data_audit.json", help="JSON destination; relative overrides resolve from the current working directory.")
    args = parser.parse_args()
    output = args.output.resolve()
    source_dir = (ROOT / "stems").resolve()
    if output == source_dir or source_dir in output.parents or output == Path(__file__).resolve():
        parser.error("--output must not overwrite original stems or this auditor")
    audit = build_audit()
    try:
        payload = json.dumps(audit, ensure_ascii=False, allow_nan=False, indent=2) + "\n"
        output.parent.mkdir(parents=True, exist_ok=True)
        output.write_text(payload, encoding="utf-8")
    except (OSError, ValueError) as exc:
        print("A audit: unable to write JSON: " + str(exc))
        return 1
    print("A audit: " + audit["status"] + "; " + str(len(audit["inputs"])) + " inputs, " + str(len(audit["errors"])) + " errors, " + str(len(audit["warnings"])) + " warnings")
    print("Output: " + str(output))
    for error in audit["errors"]:
        print(error["code"] + ": " + error["source"] + ": " + error["message"])
    return 1 if audit["errors"] else 0


if __name__ == "__main__":
    raise SystemExit(main())
