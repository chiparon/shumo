"""Solve problem A and export fields or independent-benchmark candidates."""

import argparse
import csv
import hashlib
import json
from io import BytesIO
import platform
from importlib.metadata import version
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile

import numpy as np
from openpyxl import Workbook, load_workbook

from a_model.q1 import ASSUMPTIONS, PAPER_RADII_CM, PAPER_TIMES_S, solve_q1
from a_model.radial import solve_radial
from a_model.drying import solve_drying
from audit_a import ROOT, build_audit


def protect_stems(path):
    resolved = path.resolve()
    source = (ROOT / "stems").resolve()
    if resolved == source or source in resolved.parents:
        raise ValueError("Output must not overwrite original stems")
    return resolved


def write_json(path, payload):
    path.write_text(json.dumps(payload, ensure_ascii=False, allow_nan=False, indent=2) + "\n", encoding="utf-8")


def runtime_versions():
    return {"python": platform.python_version(), **{name: version(name) for name in ("numpy", "scipy", "openpyxl")}}


def write_q1_workbook(path, template, times, radii_cm, temperature, moisture):
    workbook = load_workbook(template)
    try:
        if workbook.sheetnames != ["温度", "水分浓度"]:
            raise ValueError("Q1 template must contain 温度 and 水分浓度 sheets, in that order")
        workbook.properties.creator = ""
        workbook.properties.lastModifiedBy = ""
        workbook.properties.title = "A Q1 numerical baseline"
        workbook.properties.description = "Provisional effective boundary closure; pending team physical review"
        for sheet, field in zip(workbook.worksheets, (temperature, moisture)):
            corner = sheet.cell(1, 1).value
            sheet.delete_rows(1, sheet.max_row)
            sheet.append([corner, *[round(float(radius), 1) for radius in radii_cm]])
            for time, row in zip(times[1:], field[1:]):
                sheet.append([int(time), *[round(float(value), 4) for value in row]])
            sheet.freeze_panes = "B2"
            for row in sheet.iter_rows(min_row=2, min_col=2):
                for cell in row:
                    cell.number_format = "0.0000"
        workbook.save(path)
    finally:
        workbook.close()


def write_paper_table(path, times, radii_cm, field, *, time_unit="s"):
    with path.open("w", newline="", encoding="utf-8-sig") as stream:
        writer = csv.writer(stream)
        writer.writerow([f"time_{time_unit}", *[f"r_{radius:g}_cm" for radius in radii_cm]])
        writer.writerows([int(time) if time_unit == "s" else f"{time:.4f}", *[f"{value:.4f}" for value in row]] for time, row in zip(times, field))


def run_q1(args):
    output_dir = protect_stems(args.output_dir)
    artifact_dir = protect_stems(args.artifact_dir)
    audit = build_audit()
    if audit["errors"]:
        raise ValueError("Input audit failed: " + json.dumps(audit["errors"], ensure_ascii=False))
    rows = audit["datasets"]["environment"]["data_rows"]
    environment = np.array([[entry["cells"][f"{col}{entry['row']}"] for col in ("A", "B", "C")] for entry in rows])
    heat, moisture = solve_q1(environment, intervals=args.intervals, rtol=args.rtol, atol=args.atol)
    radii_m = np.linspace(0.0, 0.02, 21)
    temperature_field = heat.sample(radii_m)
    moisture_field = moisture.sample(radii_m)
    output_dir.mkdir(parents=True, exist_ok=True)
    artifact_dir.mkdir(parents=True, exist_ok=True)
    workbook_path = output_dir / "result1.xlsx"
    write_q1_workbook(
        workbook_path,
        ROOT / "stems" / "A题" / "附件" / "附件3" / "result1.xlsx",
        heat.time_s,
        radii_m * 100,
        temperature_field,
        moisture_field,
    )
    paper_indices = np.searchsorted(heat.time_s, PAPER_TIMES_S)
    paper_radii = np.array(PAPER_RADII_CM) / 100
    write_paper_table(output_dir / "q1_temperature_table.csv", PAPER_TIMES_S, PAPER_RADII_CM, heat.sample(paper_radii)[paper_indices])
    write_paper_table(output_dir / "q1_moisture_table.csv", PAPER_TIMES_S, PAPER_RADII_CM, moisture.sample(paper_radii)[paper_indices])
    np.savez_compressed(
        artifact_dir / "fields.npz",
        time_s=heat.time_s,
        radius_m=radii_m,
        temperature_C=temperature_field,
        moisture_dry_kgkg=moisture_field,
        temperature_volume_mean=heat.values @ heat.volume_weights / heat.volume_weights.sum(),
        moisture_volume_mean=moisture.values @ moisture.volume_weights / moisture.volume_weights.sum(),
        temperature_outward_integral=heat.outward_integral,
        moisture_outward_integral=moisture.outward_integral,
    )
    source_paths = ("src/a_model/radial.py", "src/a_model/q1.py", "tools/solve_a.py", "tools/audit_a.py", "pyproject.toml", "uv.lock", "stems/A题/A题.pdf")
    report = {
        "schema_version": 1,
        "problem": "A Q1",
        "status": "computed_provisional_physical_model",
        "assumptions": ASSUMPTIONS,
        "runtime": runtime_versions(),
        "input_hashes": audit["inputs"],
        "source_hashes": {name: hashlib.sha256((ROOT / name).read_bytes()).hexdigest() for name in source_paths},
        "temperature": heat.diagnostics,
        "moisture": moisture.diagnostics,
        "output": {
            "workbook": str(workbook_path),
            "data_rows_per_sheet": 1800,
            "radial_columns_per_sheet": 21,
            "time_unit": "s",
            "radius_unit": "cm",
            "workbook_decimals": 4,
            "raw_field_rounding": "none; fields.npz includes t=0",
        },
        "verification_scope": "This command records discrete balances, not reference comparisons or convergence studies",
    }
    write_json(artifact_dir / "run.json", report)
    print(f"Q1 complete: {workbook_path}")
    print("2 sheets x 1800 times x 21 radii; four decimals; unrounded fields retained")
    for name, solution in (("Temperature", heat), ("Moisture", moisture)):
        print(f"{name} at 1800 s: centre={solution.values[-1, 0]:.8f}, surface={solution.values[-1, -1]:.8f}; relative balance residual={solution.diagnostics['maximum_relative_balance_residual']:.3e}")
    print("Physical closure remains provisional pending team review.")


def run_benchmark(args):
    output = protect_stems(args.output)
    diagnostics_path = output.with_suffix(".diagnostics.json")
    if output == args.cases.resolve() or diagnostics_path == args.cases.resolve():
        raise ValueError("Benchmark output must not overwrite the input cases")
    manifest = json.loads(args.cases.read_text(encoding="utf-8"))
    if manifest.get("schema_version") != 1 or not manifest.get("cases"):
        raise ValueError("Expected schema_version 1 and a nonempty cases array")
    identifiers = [case["case_id"] for case in manifest["cases"]]
    if len(set(identifiers)) != len(identifiers):
        raise ValueError("Benchmark case IDs must be unique")
    all_rows, diagnostics = [], {}
    for case in manifest["cases"]:
        if case["quantity"] not in ("temperature_C", "moisture_dry_kgkg"):
            raise ValueError("Unknown benchmark quantity")
        times = np.asarray(case["times_s"], dtype=float)
        radii = np.asarray(case["radii_m"], dtype=float)
        if radii.ndim != 1 or radii.size == 0 or np.any(np.diff(radii) <= 0):
            raise ValueError("Benchmark radii must be nonempty and strictly increasing")
        solution = solve_radial(
            radius_m=case["radius_m"],
            intervals=args.intervals,
            diffusivity=case["diffusivity_m2_s"],
            surface_transfer_m_s=case["surface_transfer_m_s"],
            initial_value=case["initial_value"],
            environment_times_s=np.array([0.0, times[-1]]),
            environment_values=np.full(2, case["ambient_value"]),
            output_times_s=times,
            rtol=args.rtol,
            atol=args.atol,
        )
        field = solution.sample(radii)
        all_rows.extend((case["case_id"], float(time), float(radius), float(value)) for time, row in zip(times, field) for radius, value in zip(radii, row))
        diagnostics[case["case_id"]] = solution.diagnostics
    output.parent.mkdir(parents=True, exist_ok=True)
    with output.open("w", newline="", encoding="utf-8") as stream:
        writer = csv.writer(stream)
        writer.writerow(["case_id", "time_s", "radius_m", "value"])
        writer.writerows(all_rows)
    write_json(diagnostics_path, {"schema_version": 1, "runtime": runtime_versions(), "cases": diagnostics})
    print(f"Benchmark candidate fields: {len(all_rows)} rows -> {output}")
    print("Production finite-volume results only; no reference comparison performed by this command.")


def write_streaming_workbook(path, times, radii_m, sheets, surface=None):
    """Stream compact standard XLSX, omitting optional per-cell coordinates.

    Excel cells without r attributes advance sequentially within their row.
    Empty <c/> elements preserve positions outside the moving cylinder.
    """
    if len(times) > 1048576:
        raise ValueError("Requested complete series exceeds Excel's worksheet row limit")
    workbook = Workbook()
    workbook.remove(workbook.active)
    workbook.properties.creator = ""
    workbook.properties.lastModifiedBy = ""
    workbook.properties.description = "Provisional effective physical model; pending human team review"
    for title in sheets:
        sheet = workbook.create_sheet(title)
        sheet.cell(2, 2, 0.0).number_format = "0.0000"
    style = workbook.worksheets[0].cell(2, 2).style_id
    skeleton = BytesIO()
    workbook.save(skeleton)
    workbook.close()
    column_count = len(radii_m) + 1 + (surface is not None)
    # At most 23 columns are used by these problem-specific workbooks.
    final_column = chr(ord("A") + column_count - 1)
    with ZipFile(skeleton) as source, ZipFile(path, "w", compression=ZIP_DEFLATED, compresslevel=9) as target:
        sheet_parts = {f"xl/worksheets/sheet{index}.xml": field for index, field in enumerate(sheets.values(), 1)}
        for entry in source.infolist():
            if entry.filename not in sheet_parts:
                target.writestr(entry.filename, source.read(entry.filename))
        for part, field in sheet_parts.items():
            with target.open(part, "w") as stream:
                prefix = f'<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><dimension ref="A1:{final_column}{len(times)}"/><sheetViews><sheetView workbookViewId="0"><pane xSplit="1" ySplit="1" topLeftCell="B2" activePane="bottomRight" state="frozen"/></sheetView></sheetViews><sheetData><row r="1"><c t="inlineStr"><is><t>时间/s</t></is></c>'
                header = "".join(f"<c><v>{radius * 100:.1f}</v></c>" for radius in radii_m)
                if surface is not None:
                    header += '<c t="inlineStr"><is><t>药材表面</t></is></c>'
                stream.write((prefix + header + "</row>").encode("utf-8"))
                for begin in range(1, len(times), 512):
                    rows = []
                    for index in range(begin, min(begin + 512, len(times))):
                        row = [f'<row r="{index + 1}"><c><v>{times[index]:.4f}</v></c>']
                        row.extend("<c/>" if np.isnan(value) else f'<c s="{style}"><v>{value:.4f}</v></c>' for value in field[index])
                        if surface is not None:
                            row.append(f'<c s="{style}"><v>{surface[index]:.4f}</v></c>')
                        row.append("</row>")
                        rows.append("".join(row))
                    stream.write("".join(rows).encode("utf-8"))
                stream.write(b"</sheetData></worksheet>")


def run_long(args):
    output_dir = protect_stems(args.output_dir)
    artifact_dir = protect_stems(args.artifact_dir)
    audit = build_audit()
    if audit["errors"]:
        raise ValueError("Input audit failed: " + json.dumps(audit["errors"], ensure_ascii=False))
    environment = np.array([[row["cells"][f"{col}{row['row']}"] for col in ("A", "B", "C")] for row in audit["datasets"]["environment"]["data_rows"]])
    moving = args.command == "q4"
    radius = None
    if moving:
        radius = np.array([[row["cells"][f"A{row['row']}"], row["cells"][f"B{row['row']}"] / 100] for row in audit["datasets"]["radius"]["data_rows"]])
    result = solve_drying(
        environment, appendix=4 if moving else 3, radius_observations=radius,
        environment_tail=args.environment_tail, radius_tail=args.radius_tail,
        intervals=args.intervals, output_step_s=60 if moving else 1,
        max_time_s=args.max_hours * 3600, rtol=args.rtol, atol=args.atol,
    )
    artifact_dir.mkdir(parents=True, exist_ok=True)
    np.savez_compressed(
        artifact_dir / "fields.npz", time_s=result.time_s, radii_m=result.radii_m,
        radius_m=result.radius_m, temperature_C=result.temperature_C,
        moisture_dry_kgkg=result.moisture_dry_kgkg,
        surface_temperature_C=result.surface_temperature_C,
        surface_moisture_dry_kgkg=result.surface_moisture_dry_kgkg,
        mean_moisture_dry_kgkg=result.mean_moisture_dry_kgkg,
        outward_integral=result.outward_integral,
        final_temperature_C=result.final_temperature_C,
        final_moisture_dry_kgkg=result.final_moisture_dry_kgkg,
    )
    source_paths = ("src/a_model/drying.py", "tools/solve_a.py", "tools/audit_a.py", "pyproject.toml", "uv.lock", "stems/A题/A题.pdf")
    report = {
        "schema_version": 1, "problem": "A Q4" if moving else "A Q2/Q3",
        "runtime": runtime_versions(), "input_hashes": audit["inputs"],
        "source_hashes": {name: hashlib.sha256((ROOT / name).read_bytes()).hexdigest() for name in source_paths},
        "diagnostics": result.diagnostics,
        "output_time_policy": "Q4 every 60 s" if moving else "Q2 every 1 s through the Q3 full-domain endpoint; Q3 every 60 s",
        "terminal_row": "Additional strict endpoint; unrounded field used for criterion, not displayed four-decimal value",
    }
    write_json(artifact_dir / "run.json", report)
    if result.diagnostics["event"] is None:
        raise RuntimeError(f"No drying time claimed: {result.diagnostics['status']}; partial research fields saved to {artifact_dir}")
    output_dir.mkdir(parents=True, exist_ok=True)
    if moving:
        write_streaming_workbook(output_dir / "result4.xlsx", result.time_s, result.radii_m, {"Sheet1": result.moisture_dry_kgkg}, result.surface_moisture_dry_kgkg)
    else:
        if result.time_s[-1] < 10800:
            raise RuntimeError("Drying ended before the Q2 paper horizon; a separate continuation is required")
        write_streaming_workbook(output_dir / "result2.xlsx", result.time_s, result.radii_m, {"温度": result.temperature_C, "水分浓度": result.moisture_dry_kgkg})
        indices = np.flatnonzero(np.isclose(np.remainder(result.time_s, 60), 0, atol=1e-8, rtol=0))
        if indices[-1] != len(result.time_s) - 1:
            indices = np.r_[indices, len(result.time_s) - 1]
        write_streaming_workbook(output_dir / "result3.xlsx", result.time_s[indices], result.radii_m, {"Sheet1": result.moisture_dry_kgkg[indices]})
        paper_times = np.arange(1800, 10801, 1800)
        paper_indices = np.searchsorted(result.time_s, paper_times)
        write_paper_table(output_dir / "q2_temperature_table.csv", paper_times / 3600, PAPER_RADII_CM, result.temperature_C[paper_indices, ::5], time_unit="h")
        write_paper_table(output_dir / "q2_moisture_table.csv", paper_times / 3600, PAPER_RADII_CM, result.moisture_dry_kgkg[paper_indices, ::5], time_unit="h")
    paper_times = np.r_[np.arange(21600, result.time_s[-1], 21600), result.time_s[-1]]
    paper_indices = np.searchsorted(result.time_s, paper_times)
    paper_field = result.moisture_dry_kgkg[paper_indices, ::5]
    with (output_dir / ("q4_moisture_table.csv" if moving else "q3_moisture_table.csv")).open("w", encoding="utf-8-sig", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow(["time_h", *[f"r_{r:g}_cm" for r in PAPER_RADII_CM], *(["surface"] if moving else [])])
        for index, time, values in zip(paper_indices, paper_times, paper_field):
            row = [f"{time / 3600:.4f}", *["" if np.isnan(value) else f"{value:.4f}" for value in values]]
            if moving:
                row.append(f"{result.surface_moisture_dry_kgkg[index]:.4f}")
            writer.writerow(row)
    report["workbook_bytes"] = {name: (output_dir / name).stat().st_size for name in (["result4.xlsx"] if moving else ["result2.xlsx", "result3.xlsx"])}
    write_json(artifact_dir / "run.json", report)
    print(f"{report['problem']}: strict drying endpoint {result.time_s[-1] / 3600:.8f} h; max C={result.final_moisture_dry_kgkg.max():.12f}")
    print(f"Water balance residual: {result.diagnostics['maximum_relative_water_balance_residual']:.3e}")
    print(f"Workbook sizes: {report['workbook_bytes']}")
    print("Physical closures and unmeasured continuations remain explicit assumptions.")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest="command", required=True)
    q1 = commands.add_parser("q1", help="Solve and export the complete first question")
    q1.add_argument("--output-dir", type=Path, default=ROOT / "results" / "A")
    q1.add_argument("--artifact-dir", type=Path, default=ROOT / "artifacts" / "A" / "q1")
    q1.set_defaults(run=run_q1)
    benchmark = commands.add_parser("benchmark", help="Export candidate fields for the independent reference contract")
    benchmark.add_argument("--cases", type=Path, required=True)
    benchmark.add_argument("--output", type=Path, required=True)
    benchmark.set_defaults(run=run_benchmark)
    for name in ("q23", "q4"):
        command = commands.add_parser(name, help="Solve coupled drying through the strict full-domain endpoint")
        command.add_argument("--output-dir", type=Path, default=ROOT / "results" / "A")
        command.add_argument("--artifact-dir", type=Path, default=ROOT / "artifacts" / "A" / name)
        command.add_argument("--environment-tail", choices=("last", "last_hour_mean"), default="last")
        command.add_argument("--radius-tail", choices=("error", "last"), default="error")
        command.add_argument("--max-hours", type=float, default=168.0)
        command.add_argument("--intervals", type=int, default=3200)
        command.add_argument("--rtol", type=float, default=1e-8)
        command.add_argument("--atol", type=float, default=1e-10)
        command.set_defaults(run=run_long)
    for command in (q1, benchmark):
        command.add_argument("--intervals", type=int, default=3200, help="Computational radial intervals; exported locations are independent")
        command.add_argument("--rtol", type=float, default=1e-9)
        command.add_argument("--atol", type=float, default=1e-11)
    args = parser.parse_args()
    try:
        args.run(args)
    except (ValueError, RuntimeError, OSError, KeyError) as exc:
        parser.exit(1, f"A solver failed: {exc}\n")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
